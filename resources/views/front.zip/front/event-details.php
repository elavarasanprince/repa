<!DOCTYPE html>
<html lang="en">

<head>

    <meta name="description" content="REPA">

    <!-- ======== Page title ============ -->
    <title>REPA | Home</title>
    <?php include('includes/head.php'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.5/css/lightbox.css" integrity="sha512-DKdRaC0QGJ/kjx0U0TtJNCamKnN4l+wsMdION3GG0WVK6hIoJ1UPHRHeXNiGsXdrmq19JJxgIubb/Z7Og2qJww==" crossorigin="anonymous" referrerpolicy="no-referrer" />


</head>

<body>

    <?php include('includes/inner-header.php'); ?>

    <div class="breadcrumb-wrapper bg-cover" style="background-image: url('assets/img/breadcrumb.jpg');">
        <!-- <div class="border-shape">
                <img src="assets/img/element.png" alt="shape-img">
            </div> -->
        <div class="line-shape">
            <img src="assets/img/line-element.png" alt="shape-img">
        </div>
        <div class="container">
            <div class="page-heading">
                <h1 class="wow fadeInUp" data-wow-delay=".3s">Event Details</h1>
                <ul class="breadcrumb-items wow fadeInUp" data-wow-delay=".5s">
                    <li>
                        <a href="index.php">
                            Home
                        </a>
                    </li>
                    <li>
                        <i class="fas fa-chevron-right"></i>
                    </li>
                    <li>
                        <a href="event.php">
                            Event
                        </a>
                    </li>
                    <li>
                        <i class="fas fa-chevron-right"></i>
                    </li>
                    <li>
                        Event Details
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Project Section Start -->
    <section class="Project-details-section fix section-padding">
        <div class="container">
            <div class="project-details-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="project-details-items">
                            <div class="details-image">
                                <img src="assets/img/events/repa-launch/repa-launch2.jpg" alt="img">
                            </div>
                            <div class="row g-4 justify-content-between">
                                <div class="col-lg-7">
                                    <div class="details-content pt-5">
                                        <h3> EVENT DESCRIPTION</h3>
                                        <p>
                                            Nulla faucibus malesuada. In placerat feugiat eros ac tempor. Integer euismod massa sapien, et consequat enim laoreet et. Nulla sit amet nisi dapibus, gravida turpis sit amet, accumsan nisl. Fusce vel semper risus. Morbi congue eros sagittis, sodales turpis venenatis, iaculis dui. Proin ac purus sed nibh dapibus neque. scelerisque sed quis ante.
                                        </p>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="project-catagory">
                                        <h3>EVENTS INFO: </h3>
                                        <ul>
                                            <li>
                                            Event Details:
                                                <span>Unvieling the REPA LOGO</span>
                                            </li>
                                            <li>
                                            Date:
                                                <span>DEC 07 2024</span>
                                            </li>
                                            <li>
                                            Venue:
                                                <span>Dindigul</span>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                         
                            <div class="row g-4 pt-5">

                                <div class="swiper event-slider">
                                    <div class="swiper-wrapper">


                                        <div class="swiper-slide">
                                            <a href="assets/img/events/repa-launch/repa-launch1.jpg" data-lightbox="repa">
                                                <img src="assets/img/events/repa-launch/repa-launch1.jpg" class="img-fluid" alt="img">

                                            </a>
                                        </div>

                                        <div class="swiper-slide">
                                            <a href="assets/img/events/repa-launch/repa-launch2.jpg" data-lightbox="repa">
                                                <img src="assets/img/events/repa-launch/repa-launch2.jpg" class="img-fluid" alt="img">

                                            </a>
                                        </div>

                                      

                                        <div class="swiper-slide">
                                            <a href="assets/img/events/repa-launch/repa-launch3.jpg" data-lightbox="repa">
                                                <img src="assets/img/events/repa-launch/repa-launch3.jpg" class="img-fluid" alt="img">

                                            </a>
                                        </div>

                                        <div class="swiper-slide">
                                            <a href="assets/img/events/repa-launch/repa-launch4.jpg" data-lightbox="repa">
                                                <img src="assets/img/events/repa-launch/repa-launch4.jpg" class="img-fluid" alt="img">

                                            </a>
                                        </div>

                                        <div class="swiper-slide">
                                            <a href="assets/img/events/repa-launch/repa-launch5.jpg" data-lightbox="repa"> 
                                                <img src="assets/img/events/repa-launch/repa-launch5.jpg" class="img-fluid" alt="img">
                                            </a>
                                        </div>

                                        <div class="swiper-slide">
                                            <a href="assets/img/events/repa-launch/repa-launch6.jpg" data-lightbox="repa">
                                                <img src="assets/img/events/repa-launch/repa-launch6.jpg" class="img-fluid" alt="img">

                                            </a>
                                        </div>

                                        <div class="swiper-slide">
                                            <a href="assets/img/events/repa-launch/repa-launch7.jpg" data-lightbox="repa">
                                                <img src="assets/img/events/repa-launch/repa-launch7.jpg" class="img-fluid" alt="img">

                                            </a>
                                        </div>


                                    </div>
                                    <div class="swiper-button-next"></div>
                                    <div class="swiper-button-prev"></div>

                                    
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
    </section>











    <?php include("includes/footer.php"); ?>


    <?php include("includes/script.php"); ?>

    <script>
    lightbox.option({
      'resizeDuration': 200,
      'wrapAround': true
    })
</script>



</body>

</html>