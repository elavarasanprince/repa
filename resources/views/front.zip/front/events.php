<!DOCTYPE html>
<html lang="en">

<head>

    <meta name="description" content="REPA">

    <!-- ======== Page title ============ -->
    <title>REPA | Home</title>
    <?php include('includes/head.php'); ?>

</head>

<body>

    <?php include('includes/inner-header.php'); ?>

    <div class="breadcrumb-wrapper bg-cover" style="background-image: url('assets/img/breadcrumb.jpg');">
        <!-- <div class="border-shape">
                <img src="assets/img/element.png" alt="shape-img">
            </div> -->
        <div class="line-shape">
            <img src="assets/img/line-element.png" alt="shape-img">
        </div>
        <div class="container">
            <div class="page-heading">
                <h1 class="wow fadeInUp" data-wow-delay=".3s">Our Latest Event</h1>
                <ul class="breadcrumb-items wow fadeInUp" data-wow-delay=".5s">
                    <li>
                        <a href="index.php">
                            Home
                        </a>
                    </li>
                    <li>
                        <i class="fas fa-chevron-right"></i>
                    </li>
                    <li>
                    Our Latest Event
                    </li>
                </ul>
            </div>
        </div>
    </div>


    <!-- News Section Start -->
    <section class="news-section fix section-padding">
        <div class="container ">
           
                <div class="section-title  text-center">
                    <span class="wow fadeInUp">Latest Events</span>
                    <h2 class="wow fadeInUp" data-wow-delay=".3s">
                        Our Latest Event
                    </h2>
                </div>
               
           <div class="row justify-content-center">
            <div class="col-lg-4">
            <div class="news-card-items">
                            <div class="news-image">
                                <img src="assets/img/events/event-7.png" alt="news-img">
                                <div class="post-date">
                                    <h3>
                                        29 <br>
                                        <span>Sept</span>
                                    </h3>
                                </div>
                            </div>
                            <div class="news-content">
                                <ul>
                                    <li>
                                        <i class="fa-regular fa-user"></i>
                                        By Admin
                                    </li>
                                    <li>
                                        <i class="fa-solid fa-tag"></i>
                                       REPA Launch 
                                    </li>
                                </ul>
                                <h3>
                                    <a href="event-details.php">Unvieling the REPA LOGO  </a>
                                </h3>
                                <a href="event-details.php" class="theme-btn-2 mt-3">
                                    read More
                                    <i class="fa-solid fa-arrow-right-long"></i>
                                </a>
                            </div>
                        </div>
            </div>
             
           </div>
          
        </div>
    </section>

    <?php include("includes/footer.php"); ?>


    <?php include("includes/script.php"); ?>



</body>

</html>