<!-- ========== Meta Tags ========== -->
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="author" content="Techovirish">
<meta name="description" content="REPA">

<!--<< Favicon >>-->
<link rel="shortcut icon" href="{{ asset('assets/img/favicon.png') }}">

<!--<< Bootstrap CSS >>-->
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">

<!--<< All Min CSS >>-->
<link rel="stylesheet" href="{{ asset('assets/css/all.min.css') }}">

<!--<< Animate.css >>-->
<link rel="stylesheet" href="{{ asset('assets/css/animate.css') }}">

<!--<< Magnific Popup.css >>-->
<link rel="stylesheet" href="{{ asset('assets/css/magnific-popup.css') }}">

<!--<< MeanMenu.css >>-->
<link rel="stylesheet" href="{{ asset('assets/css/meanmenu.css') }}">

<!--<< Swiper Bundle.css >>-->
<link rel="stylesheet" href="{{ asset('assets/css/swiper-bundle.min.css') }}">

<!--<< Nice Select.css >>-->
<link rel="stylesheet" href="{{ asset('assets/css/nice-select.css') }}">

<!--<< Main.css >>-->
<link rel="stylesheet" href="{{ asset('assets/css/main.css') }}">
